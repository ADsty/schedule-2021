@ExperimentalTime
fun testAllTransactions(connection: Connection) {
val threadsAmount = RequestType.values().size
var lastDeadlines = 0
if (configProperties
.getProperty("config.isReadCommittedTestEnabled").toBoolean()) {
val readCommittedExecutor = Executors.newFixedThreadPool(threadsAmount)
testTransactions(connection, readCommittedExecutor, `READ COMMITTED`, lastDeadlines)
while (!readCommittedExecutor.isTerminated) {
}
lastDeadlines += insertRequestsAmount
}
if (configProperties
.getProperty("config.isRepeatableReadTestEnabled").toBoolean()) {
val repeatableReadExecutor = Executors.newFixedThreadPool(threadsAmount)
testTransactions(connection, repeatableReadExecutor, `REPEATABLE READ`, lastDeadlines)
while (!repeatableReadExecutor.isTerminated) {
}
lastDeadlines += insertRequestsAmount
}
if (configProperties
.getProperty("config.isSerializableTestEnabled").toBoolean()) {
val serializableExecutor = Executors.newFixedThreadPool(threadsAmount)
testTransactions(connection, serializableExecutor, SERIALIZABLE, lastDeadlines)
while (!serializableExecutor.isTerminated) {
}
}
}

private fun testTransactions(
connection: Connection,
executor: ExecutorService,
transactionType: TransactionType,
lastDeadlines: Int
) {
val selectTransactionWorker = Runnable {
startTransaction(connection, SELECT, transactionType, selectRequestsAmount, lastDeadlines)
}
val insertTransactionWorker = Runnable {
startTransaction(connection, INSERT, transactionType, insertRequestsAmount, lastDeadlines)
}
val updateTransactionWorker = Runnable {
startTransaction(connection, UPDATE, transactionType, updateRequestsAmount, lastDeadlines)
}
with(executor) {
execute(selectTransactionWorker)
execute(insertTransactionWorker)
execute(updateTransactionWorker)
}
executor.shutdown()
}