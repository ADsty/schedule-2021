fun createConnection(): Connection? {
    val connection: Connection?

    try {
        val driver = Driver()
        DriverManager.registerDriver(driver)

        connection = DriverManager.getConnection(DB_URL, DB_PROPERTIES)
    } catch (e: SQLException) {
        if (DEV_MODE) {
            println("Ошибка подключения базы данных\n")
            e.printStackTrace()
        }
        return null
    }
    return connection
}

fun getApiResponse(url: String, isPlanApiUsed: Boolean = false): String? {
    val request = Request.Builder().url(url).apply {
        if (isPlanApiUsed) {
            addHeader("X-Studyplan-Repository-Api-Key", PLAN_API_KEY)
        }
    }.build()

    val response: Response

    try {
        response = httpClient.newCall(request).execute()
    } catch (e: IOException) {
        if (DEV_MODE) {
            e.printStackTrace()
        }
        return null
    }

    return response.body?.string()
}

fun executeBatch(batch: Statement, tableName: String, isInsertionFinish: Boolean = true) {
    try {
        batch.executeBatch()
    } catch (e: SQLException) {
        if (DEV_MODE) {
            logger.log("$tableName executeBatch Exception")
            e.printStackTrace()
        }
        return
    }

    if (isInsertionFinish) {
        logger.log("$tableName INSERTION FINISHED")
    }
}

val gson: Gson = GsonBuilder()
    .serializeNulls()
    .setDateFormat(DateFormat.SHORT, DateFormat.SHORT)
    .create()

val httpClient = OkHttpClient()
    .newBuilder()
    .connectTimeout(1, TimeUnit.HOURS)
    .readTimeout(1, TimeUnit.HOURS)
    .build()