@ExperimentalTime
fun insertAllTables(connection: Connection) {

    var duration = measureTime { insertFaculty(connection) }
    logger.log("[FACULTY] DURATION = $duration\n====")

    duration = measureTime { insertDepartment(connection) }
    logger.log("[DEPARTMENT] DURATION = $duration\n====")

    duration = measureTime { insertTaskType(connection) }
    logger.log("[TASK_TYPE] DURATION = $duration\n====")

    duration = measureTime { insertSubjectType(connection) }
    logger.log("[SUBJECT_TYPE] DURATION = $duration\n====")

    duration = measureTime { insertLessonType(connection) }
    logger.log("[LESSON_TYPE] DURATION = $duration\n====")

    duration = measureTime { insertTeacher(connection) }
    logger.log("[TEACHER] DURATION = $duration\n====")

    duration = measureTime { insertGroupSpecializationAndGroupSpecialization(connection) }
    logger.log("[GROUP SPECIALIZATION GROUP_SPECIALIZATION] DURATION = $duration\n====")

    duration = measureTime { insertStudent(connection) }
    logger.log("[STUDENTS] DURATION = $duration\n====")

    duration = measureTime { insertSemester(connection) }
    logger.log("[SEMESTERS] DURATION = $duration\n====")

    duration = measureTime { insertSubjectLessonLessonTeacherLessonGroup(connection) }
    logger.log("[SUBJECT LESSON LESSON_TEACHER LESSON_GROUP] DURATION = $duration\n====")

    duration = measureTime { insertProfile(connection) }
    logger.log("[PROFILE] DURATION = $duration\n====")

    duration = measureTime { insertProfileSubject(connection) }
    logger.log("[PROFILE_SUBJECT] DURATION = $duration\n====")

    duration = measureTime { insertDeadline(connection) }
    logger.log("[DEADLINE] DURATION = $duration\n====")

    duration = measureTime { insertProgress(connection) }
    logger.log("[PROGRESS] DURATION = $duration\n====")

    duration = measureTime { insertTask(connection) }
    logger.log("[TASK] DURATION = $duration\n====")
}

fun insertDepartment(connection: Connection) {

    val departmentBatch = connection.createStatement()
    val facultyResultSet = connection.createStatement().executeQuery("SELECT id, name FROM schema_schedule.faculty")

    val divisionURL = StringBuilder(ApiURL.DEPARTMENT)
    val divisionLength = divisionURL.length
    var apiPage = 1

    do {
        divisionURL.append("$apiPage")
        val response = getApiResponse(divisionURL.toString(), true)
        divisionURL.setLength(divisionLength)
        apiPage++

        val divisionContainer = gson.fromJson(response, DivisionContainer::class.java)

        divisionFullList.addAll(divisionContainer.divisionList)

    } while (divisionContainer.next != null)

    for (department in divisionFullList) {
        val departmentParent = facultyApiIdToNameMap[department.parentId] ?: continue

        if (department.closeDate == null) {
            val facultyID = facultyNameToIdMap[departmentParent]
            departmentBatch.addBatch(
                """
                INSERT INTO schema_schedule.department (name, faculty_id)
                SELECT '${department.name}', $facultyID
                WHERE NOT EXISTS(
                SELECT 1
                FROM schema_schedule.department
                WHERE name = '${department.name}'
                AND faculty_id = $facultyID)""".trimMargin()
            )
        }
    }

    executeBatch(departmentBatch, tableName)
}

fun insertStudent(connection: Connection) {

    val studentBatch = connection.createStatement()

    for (i in 0..GENERATED_STUDENT_AMOUNT) {

        val fakeName = faker.name
        val studentName = "${fakeName.firstName()} ${fakeName.lastName()}".replace("\'", "")

        val groupIds = fastIdSelecting(connection, "\"GROUP\"")
        val groupId = groupIds.random()

        studentBatch.addBatch(
            """
            INSERT INTO schema_schedule.student(name, group_id)
                SELECT '$studentName', $groupId
                WHERE NOT EXISTS(
                SELECT 1
                FROM schema_schedule.student
                WHERE name = '$studentName'            
                AND group_id = $groupId
                )"""
        )
    }

    executeBatch(studentBatch, tableName)
}